package main

import "github.com/tools/internal/commands"

func main() {
	commands.Start()
}