import React from "react";

export const Statistics = () => {
  return (
    <section className="lesson">
      <p>Statistics</p>
    </section>
  )
}
