import React from "react";

export const NoData = () => {
  return (
    <section className="no-data">
      <h2>Выберите тему</h2>
    </section>
  )
}
