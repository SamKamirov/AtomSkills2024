export const groupList = [
  {
    id: 1,
    title: 'Тема 1'
  },
  {
    id: 2,
    title: 'Тема 2'
  },
  {
    id: 3,
    title: 'Тема 3'
  },
  {
    id: 4,
    title: 'Тема 4'
  }
]

export const SERVER_URL = 'http://172.20.7.23:8082'
